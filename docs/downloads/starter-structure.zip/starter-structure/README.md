# HISafe — Starter structure

Anonymous authors.

This archive provides reserved src/, data/, configs/, and results/ directories.
It does not include the website, benchmark implementation, data, or results.
Research materials and an applicable license will be added by the authors.
